import json
import boto3

# ==============================
# AWS CLIENTS
# ==============================

bedrock = boto3.client(
    service_name="bedrock-runtime",
    region_name="ap-southeast-1"
)

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("customer-transaction")

# ==============================
# LAMBDA HANDLER
# ==============================

def lambda_handler(event, context):
    try:
        # =====================================================
        # 1. FETCH ALL RECORDS FROM DYNAMODB
        # =====================================================

        response = table.scan()
        items = response.get("Items", [])

        if not items:
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "count": 0,
                    "data": []
                })
            }

        # =====================================================
        # 2. PREPARE AI INPUT
        # =====================================================

        ai_input = []

        for item in items:
            ai_input.append({
                "item_name": item.get("item_name"),
                "item_type": item.get("item_type", "Unknown"),
                "merchant_name": item.get("merchant_name"),
                "merchant_type": item.get("merchant_type"),
                "possible_tax_relief_category": item.get("possible_tax_relief_category")
            })

        # =====================================================
        # 3. STRICT PROMPT (CONSISTENT SENTENCE)
        # =====================================================

        prompt = f"""
You are a Malaysian tax relief reasoning AI.

DATA:
{json.dumps(ai_input)}

========================
TASK
========================
Generate ONE reasoning sentence per item.

DO NOT change:
- item_name
- item_type
- possible_tax_relief_category

ONLY generate:
- reasoning_case
- reasoning

========================
REASONING CASE RULES
========================
- clear    → item name obvious + merchant supports
- model    → product model name (e.g. Yonex 100)
- vague    → unclear name (e.g. SKU12345)
- conflict → mismatch between item and merchant

========================
STRICT SENTENCE TEMPLATES
========================

1. CLEAR:
"You bought \"<item_name>\" from <merchant_name>, which is a <merchant_type>. AI classified this as a <item_type>, making it eligible under <category>."

2. MODEL:
"\"<item_name>\" looks like a product model name. AI recognised it as a <item_type>, and given that <merchant_name> is a <merchant_type>, this purchase is likely claimable under <category>."

3. VAGUE:
"The item name \"<item_name>\" doesn't tell us much on its own, but since this was purchased at <merchant_name> — a <merchant_type> — AI treated it as a potentially relevant item that could fall under <category>."

4. CONFLICT:
"The item \"<item_name>\" suggests <item_type>, but <merchant_name> is a <merchant_type>, creating a mismatch. AI still classified it under <category>."

========================
OUTPUT FORMAT (STRICT JSON)
========================

[
  {{
    "item_name": string,
    "reasoning_case": "clear" | "model" | "vague" | "conflict",
    "reasoning": string
  }}
]

RULES:
- EXACTLY match item_name
- ONE sentence only
- NO extra text
"""

        # =====================================================
        # 4. CALL BEDROCK
        # =====================================================

        response = bedrock.converse(
            modelId="apac.amazon.nova-micro-v1:0",
            messages=[{"role": "user", "content": [{"text": prompt}]}]
        )

        response_text = response["output"]["message"]["content"][0]["text"]

        if not response_text:
            raise Exception("Empty response from Bedrock")

        ai_result = json.loads(response_text)

        # =====================================================
        # 5. MAP AI RESULT BACK
        # =====================================================

        final_data = []

        for item in items:
            match = next(
                (ai for ai in ai_result if ai["item_name"] == item["item_name"]),
                None
            )

            enriched = item.copy()

            if match:
                enriched["reasoning_case"] = match.get("reasoning_case")
                enriched["reasoning"] = match.get("reasoning")

            final_data.append(enriched)

        # =====================================================
        # 6. RESPONSE
        # =====================================================

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "count": len(final_data),
                "data": final_data
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }