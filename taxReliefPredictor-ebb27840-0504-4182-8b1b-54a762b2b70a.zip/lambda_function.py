import json
import boto3

# ==============================
# AWS CLIENTS
# ==============================

bedrock = boto3.client(
    service_name="bedrock-runtime",
    region_name="ap-southeast-1"
)

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("customer-transaction")

# ==============================
# MOCK DATA
# ==============================

merchant_db = {
    "merchant_123": {
        "merchant_name": "Al-Ikhsan Sports",
        "merchant_type": "Sports Equipment Seller"
    },
    "merchant_456": {
        "merchant_name": "Senheng",
        "merchant_type": "Electronics Retailer"
    },
    "merchant_789": {
        "merchant_name": "Popular Bookstore",
        "merchant_type": "Books & Education Store"
    }
}

invoice_db = {
    "merchant_123": [
        {"total_amount": 399, "item": {"item_name": "Wilson Pro 99"}},
        {"total_amount": 450, "item": {"item_name": "Yonex 100"}}
    ],
    "merchant_456": [
        {"total_amount": 2500, "item": {"item_name": "Laptop"}},
        {"total_amount": 120, "item": {"item_name": "Wireless Mouse"}},
        {"total_amount": 220, "item": {"item_name": "SKU12345"}}
    ],
    "merchant_789": [
        {"total_amount": 85, "item": {"item_name": "Math Textbook"}},
        {"total_amount": 45, "item": {"item_name": "Science Workbook"}},
        {"total_amount": 95, "item": {"item_name": "General Purchase"}}
    ]
}

# ==============================
# LAMBDA HANDLER
# ==============================

def lambda_handler(event, context):
    try:
        # ==============================
        # 1. INPUT
        # ==============================

        body = json.loads(event.get("body", "{}"))

        merchant_id = body.get("merchant_id")
        amount = body.get("amount")
        transaction_no = body.get("transaction_no")

        if not merchant_id or amount is None or not transaction_no:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "merchant_id, amount, and transaction_no are required"
                })
            }

        # ==============================
        # 2. LOOKUP INVOICE
        # ==============================

        invoices = invoice_db.get(merchant_id, [])
        item_name = None

        for inv in invoices:
            if float(inv["total_amount"]) == float(amount):
                item_name = inv["item"]["item_name"]
                break

        if not item_name:
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "Invoice not found"
                })
            }

        # ==============================
        # 3. GET MERCHANT INFO
        # ==============================

        merchant = merchant_db.get(merchant_id)

        if not merchant:
            return {
                "statusCode": 404,
                "body": json.dumps({
                    "error": "Merchant not found"
                })
            }

        merchant_name = merchant["merchant_name"]
        merchant_type = merchant["merchant_type"]

        # ==============================
        # 4. AI CLASSIFICATION
        # ==============================

        prompt = f"""
Classify item and Malaysian tax relief.

Item: {item_name}
Merchant: {merchant_name}
Merchant Type: {merchant_type}

========================
STRICT OUTPUT FORMAT
========================

Return ONLY valid JSON:

{{
  "item_type": "<string>",
  "possible_tax_relief_category": "<string>"
}}

RULES:
- No explanation
- No extra text

FEW SHOT SAMPLE FOR possible_tax_relief_category

Merchant: Anytime Fitness (JB) (TNG-MID-202) | Item: Badminton Racket | Category: Sports | MSIC: Sports Equipment & Gym Fees | Relief_Group: Lifestyle | Relief_Item: Sports Equipment & Gym Fees | Keywords: racket, gym, running shoes, jersey | Eligible: True | Reason: Qualifies under Sports Equipment & Gym Fees
Merchant: Q-dees (Penang) (TNG-MID-245) | Item: Monthly Tuition Fee | Category: Education | MSIC: Child Care Fees | Relief_Group: Family | Relief_Item: Child Care Fees | Keywords: tadika, kindergarten, nursery, daycare | Eligible: True | Reason: Qualifies under Child Care Fees
Merchant: Eco-Friendly Gadgets (Ipoh) (TNG-MID-289) | Item: Smart Door Lock | Category: Security | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Guardian (KK) (TNG-MID-209) | Item: Flu Vaccination | Category: Healthcare | MSIC: Full Medical Check-up / Vaccine | Relief_Group: Medical | Relief_Item: Full Medical Check-up / Vaccine | Keywords: vaccine, blood test, screening, vitamins | Eligible: True | Reason: Qualifies under Full Medical Check-up / Vaccine
Merchant: Eco-Friendly Gadgets (JB) (TNG-MID-234) | Item: Food Waste Grinder | Category: ESG | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Klinik Anda (Penang) (TNG-MID-276) | Item: Multivitamins | Category: Healthcare | MSIC: Full Medical Check-up / Vaccine | Relief_Group: Medical | Relief_Item: Full Medical Check-up / Vaccine | Keywords: vaccine, blood test, screening, vitamins | Eligible: True | Reason: Qualifies under Full Medical Check-up / Vaccine
Merchant: Mamak Corner (KL) (TNG-MID-297) | Item: Iced Latte | Category: Beverage | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Beverage purchases are not tax-deductible
Merchant: Tadika Mesra (PJ) (TNG-MID-255) | Item: Monthly Tuition Fee | Category: Education | MSIC: Child Care Fees | Relief_Group: Family | Relief_Item: Child Care Fees | Keywords: tadika, kindergarten, nursery, daycare | Eligible: True | Reason: Qualifies under Child Care Fees
Merchant: Tealive (KL) (TNG-MID-285) | Item: Nasi Lemak Ayam | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Ramly Burger Stall (KK) (TNG-MID-270) | Item: Chicken Burger | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: OldTown White Coffee (KL) (TNG-MID-296) | Item: Nasi Lemak Ayam | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Maxis Centre (KL) (TNG-MID-291) | Item: Prepaid Top-up | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
Merchant: Kinokuniya (Ipoh) (TNG-MID-253) | Item: Monthly Magazine | Category: Reading | MSIC: Reading Materials | Relief_Group: Lifestyle | Relief_Item: Reading Materials | Keywords: book, magazine, novel, textbook | Eligible: True | Reason: Qualifies under Reading Materials
Merchant: Eco-Friendly Gadgets (JB) (TNG-MID-204) | Item: Smart Door Lock | Category: Security | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Machines (KL) (TNG-MID-249) | Item: iPad Air M2 | Category: Tech | MSIC: Hardware: PC/Smartphone/Tablet | Relief_Group: Lifestyle | Relief_Item: Hardware: PC/Smartphone/Tablet | Keywords: iphone, laptop, samsung, ipad, huawei, tablet | Eligible: True | Reason: Qualifies under Hardware: PC/Smartphone/Tablet
Merchant: Popular Bookstore (JB) (TNG-MID-295) | Item: Monthly Magazine | Category: Reading | MSIC: Reading Materials | Relief_Group: Lifestyle | Relief_Item: Reading Materials | Keywords: book, magazine, novel, textbook | Eligible: True | Reason: Qualifies under Reading Materials
Merchant: Eco-Friendly Gadgets (KK) (TNG-MID-214) | Item: Food Waste Grinder | Category: ESG | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Eagle Eye CCTV (Ipoh) (TNG-MID-248) | Item: Smart Door Lock | Category: Security | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Mamak Corner (KL) (TNG-MID-261) | Item: Nasi Lemak Ayam | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Times Bookshop (KL) (TNG-MID-282) | Item: E-Book Subscription | Category: Digital | MSIC: Reading Materials | Relief_Group: Lifestyle | Relief_Item: Reading Materials | Keywords: book, magazine, novel, textbook | Eligible: True | Reason: Qualifies under Reading Materials
Merchant: Smart Reader Kids (Penang) (TNG-MID-258) | Item: Monthly Tuition Fee | Category: Education | MSIC: Child Care Fees | Relief_Group: Family | Relief_Item: Child Care Fees | Keywords: tadika, kindergarten, nursery, daycare | Eligible: True | Reason: Qualifies under Child Care Fees
Merchant: ADT Alarm Systems (Penang) (TNG-MID-233) | Item: Smart Door Lock | Category: Security | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Anytime Fitness (KL) (TNG-MID-229) | Item: Badminton Racket | Category: Sports | MSIC: Sports Equipment & Gym Fees | Relief_Group: Lifestyle | Relief_Item: Sports Equipment & Gym Fees | Keywords: racket, gym, running shoes, jersey | Eligible: True | Reason: Qualifies under Sports Equipment & Gym Fees
Merchant: OldTown White Coffee (KK) (TNG-MID-211) | Item: Nasi Lemak Ayam | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Dell Store (JB) (TNG-MID-238) | Item: Samsung S24 | Category: Tech | MSIC: Hardware: PC/Smartphone/Tablet | Relief_Group: Lifestyle | Relief_Item: Hardware: PC/Smartphone/Tablet | Keywords: iphone, laptop, samsung, ipad, huawei, tablet | Eligible: True | Reason: Qualifies under Hardware: PC/Smartphone/Tablet
Merchant: Samsung Experience Store (KK) (TNG-MID-298) | Item: Wireless Mouse | Category: Tech | MSIC: Hardware: PC/Smartphone/Tablet | Relief_Group: Lifestyle | Relief_Item: Hardware: PC/Smartphone/Tablet | Keywords: iphone, laptop, samsung, ipad, huawei, tablet | Eligible: True | Reason: Qualifies under Hardware: PC/Smartphone/Tablet
Merchant: ZUS Coffee (KK) (TNG-MID-266) | Item: Chicken Burger | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Celcom BlueCube (Penang) (TNG-MID-241) | Item: Monthly Fiber Bill | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
Merchant: Borders (KL) (TNG-MID-206) | Item: Monthly Magazine | Category: Reading | MSIC: Reading Materials | Relief_Group: Lifestyle | Relief_Item: Reading Materials | Keywords: book, magazine, novel, textbook | Eligible: True | Reason: Qualifies under Reading Materials
Merchant: Ramly Burger Stall (Ipoh) (TNG-MID-231) | Item: Chicken Burger | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Decathlon (JB) (TNG-MID-219) | Item: Swimming Goggles | Category: Sports | MSIC: Sports Equipment & Gym Fees | Relief_Group: Lifestyle | Relief_Item: Sports Equipment & Gym Fees | Keywords: racket, gym, running shoes, jersey | Eligible: True | Reason: Qualifies under Sports Equipment & Gym Fees
Merchant: Little Caliphs (JB) (TNG-MID-235) | Item: Monthly Tuition Fee | Category: Education | MSIC: Child Care Fees | Relief_Group: Family | Relief_Item: Child Care Fees | Keywords: tadika, kindergarten, nursery, daycare | Eligible: True | Reason: Qualifies under Child Care Fees
Merchant: OldTown White Coffee (JB) (TNG-MID-278) | Item: Nasi Lemak Ayam | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: Klinik Anda (KL) (TNG-MID-217) | Item: Health Screening | Category: Healthcare | MSIC: Full Medical Check-up / Vaccine | Relief_Group: Medical | Relief_Item: Full Medical Check-up / Vaccine | Keywords: vaccine, blood test, screening, vitamins | Eligible: True | Reason: Qualifies under Full Medical Check-up / Vaccine
Merchant: Celcom BlueCube (Penang) (TNG-MID-272) | Item: Monthly Fiber Bill | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
Merchant: Watsons (Penang) (TNG-MID-299) | Item: Flu Vaccination | Category: Healthcare | MSIC: Full Medical Check-up / Vaccine | Relief_Group: Medical | Relief_Item: Full Medical Check-up / Vaccine | Keywords: vaccine, blood test, screening, vitamins | Eligible: True | Reason: Qualifies under Full Medical Check-up / Vaccine
Merchant: Watsons (KL) (TNG-MID-226) | Item: Flu Vaccination | Category: Healthcare | MSIC: Full Medical Check-up / Vaccine | Relief_Group: Medical | Relief_Item: Full Medical Check-up / Vaccine | Keywords: vaccine, blood test, screening, vitamins | Eligible: True | Reason: Qualifies under Full Medical Check-up / Vaccine
Merchant: DirectD (JB) (TNG-MID-244) | Item: Laptop Battery | Category: Tech | MSIC: Hardware: PC/Smartphone/Tablet | Relief_Group: Lifestyle | Relief_Item: Hardware: PC/Smartphone/Tablet | Keywords: iphone, laptop, samsung, ipad, huawei, tablet | Eligible: True | Reason: Qualifies under Hardware: PC/Smartphone/Tablet
Merchant: U Mobile Store (JB) (TNG-MID-274) | Item: Prepaid Top-up | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
Merchant: Aquaria KLCC (JB) (TNG-MID-232) | Item: Family Entry Pass | Category: Leisure | MSIC: Domestic Tourism Expenses | Relief_Group: Tourism | Relief_Item: Domestic Tourism Expenses | Keywords: zoo, theme park, entrance, hotel | Eligible: True | Reason: Qualifies under Domestic Tourism Expenses
Merchant: Smart Reader Kids (KL) (TNG-MID-292) | Item: Monthly Tuition Fee | Category: Education | MSIC: Child Care Fees | Relief_Group: Family | Relief_Item: Child Care Fees | Keywords: tadika, kindergarten, nursery, daycare | Eligible: True | Reason: Qualifies under Child Care Fees
Merchant: Tealive (KK) (TNG-MID-280) | Item: Chicken Burger | Category: Food | MSIC: N/A | Relief_Group: N/A | Relief_Item: N/A | Keywords: meal, burger, coffee, nasi lemak | Eligible: False | Reason: Food purchases are not tax-deductible
Merchant: TM Unifi (PJ) (TNG-MID-240) | Item: Prepaid Top-up | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
Merchant: Thunder Match (TMT) (Penang) (TNG-MID-284) | Item: iPad Air M2 | Category: Tech | MSIC: Hardware: PC/Smartphone/Tablet | Relief_Group: Lifestyle | Relief_Item: Hardware: PC/Smartphone/Tablet | Keywords: iphone, laptop, samsung, ipad, huawei, tablet | Eligible: True | Reason: Qualifies under Hardware: PC/Smartphone/Tablet
Merchant: Eco-Friendly Gadgets (PJ) (TNG-MID-207) | Item: Food Waste Grinder | Category: ESG | MSIC: Home Security & Composting | Relief_Group: Lifestyle (ESG) | Relief_Item: Home Security & Composting | Keywords: cctv, security system, composting | Eligible: True | Reason: Qualifies under Home Security & Composting
Merchant: Digi Store (JB) (TNG-MID-267) | Item: Prepaid Top-up | Category: Bill | MSIC: Internet Subscription | Relief_Group: Lifestyle | Relief_Item: Internet Subscription | Keywords: unifi, maxis fiber, time internet, broadband | Eligible: True | Reason: Qualifies under Internet Subscription
"""

        response = bedrock.converse(
            modelId="apac.amazon.nova-micro-v1:0",
            messages=[{
                "role": "user",
                "content": [{"text": prompt}]
            }]
        )

        response_text = response["output"]["message"]["content"][0]["text"]

        # Safe JSON parse
        try:
            result = json.loads(response_text)
        except:
            result = {
                "item_type": "Unknown",
                "possible_tax_relief_category": "Lifestyle Relief"
            }

        # ==============================
        # 5. SAVE TO DYNAMODB
        # ==============================

        item_record = {
            "transaction_id": str(transaction_no),
            "merchant_id": str(merchant_id),
            "merchant_name": str(merchant_name),
            "merchant_type": str(merchant_type),
            "item_name": str(item_name),
            "item_type": str(result.get("item_type", "")),
            "possible_tax_relief_category": str(result.get("possible_tax_relief_category", "")),
            "amount": str(amount) 
        }

        table.put_item(Item=item_record)

        # ==============================
        # 6. RESPONSE
        # ==============================

        return {
            "statusCode": 200,
            "body": json.dumps(item_record)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }